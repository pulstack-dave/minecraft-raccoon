package net.minecraft.client.gui.contextualbar;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ExperienceBarRenderer implements ContextualBarRenderer {
    private static final ResourceLocation EXPERIENCE_BAR_BACKGROUND_SPRITE = ResourceLocation.withDefaultNamespace("hud/experience_bar_background");
    private static final ResourceLocation EXPERIENCE_BAR_PROGRESS_SPRITE = ResourceLocation.withDefaultNamespace("hud/experience_bar_progress");
    private final Minecraft minecraft;

    public ExperienceBarRenderer(Minecraft p_416079_) {
        this.minecraft = p_416079_;
    }

    @Override
    public void renderBackground(GuiGraphics p_416499_, DeltaTracker p_416464_) {
        LocalPlayer localplayer = this.minecraft.player;
        int i = this.left(this.minecraft.getWindow());
        int j = this.top(this.minecraft.getWindow());
        int k = localplayer.getXpNeededForNextLevel();
        if (k > 0) {
            int l = (int)(localplayer.experienceProgress * 183.0F);
            p_416499_.blitSprite(RenderPipelines.GUI_TEXTURED, EXPERIENCE_BAR_BACKGROUND_SPRITE, i, j, 182, 5);
            if (l > 0) {
                p_416499_.blitSprite(RenderPipelines.GUI_TEXTURED, EXPERIENCE_BAR_PROGRESS_SPRITE, 182, 5, 0, 0, i, j, l, 5);
            }
        }
    }

    @Override
    public void render(GuiGraphics p_415587_, DeltaTracker p_416114_) {
    }
}
