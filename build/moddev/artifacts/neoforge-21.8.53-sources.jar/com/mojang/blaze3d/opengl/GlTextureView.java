package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.textures.GpuTextureView;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GlTextureView extends GpuTextureView {
    private boolean closed;

    protected GlTextureView(GlTexture p_423648_, int p_423671_, int p_423545_) {
        super(p_423648_, p_423671_, p_423545_);
        p_423648_.addViews();
    }

    @Override
    public boolean isClosed() {
        return this.closed;
    }

    @Override
    public void close() {
        if (!this.closed) {
            this.closed = true;
            this.texture().removeViews();
        }
    }

    public GlTexture texture() {
        return (GlTexture)super.texture();
    }
}
