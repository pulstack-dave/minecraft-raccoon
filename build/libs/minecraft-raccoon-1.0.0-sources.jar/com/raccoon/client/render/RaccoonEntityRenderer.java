package com.raccoon.client.render;

import com.raccoon.RaccoonMod;
import com.raccoon.client.model.RaccoonEntityModel;
import com.raccoon.client.model.RaccoonModelLayers;
import com.raccoon.entity.RaccoonEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_927;

@Environment(EnvType.CLIENT)
public class RaccoonEntityRenderer extends class_927<RaccoonEntity, RaccoonEntityModel<RaccoonEntity>> {
    private static final class_2960 TEXTURE = new class_2960(RaccoonMod.MOD_ID, "textures/entity/raccoon/raccoon.png");

    public RaccoonEntityRenderer(class_5617.class_5618 context) {
        super(context, new RaccoonEntityModel<>(context.method_32167(RaccoonModelLayers.RACCOON)), 0.4F);
    }

    @Override
    public class_2960 getTexture(RaccoonEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(RaccoonEntity entity, class_4587 matrices, float amount) {
        if (entity.method_6109()) {
            matrices.method_22905(0.55F, 0.55F, 0.55F);
        } else {
            matrices.method_22905(0.85F, 0.85F, 0.85F);
        }
        super.method_4042(entity, matrices, amount);
    }
}
