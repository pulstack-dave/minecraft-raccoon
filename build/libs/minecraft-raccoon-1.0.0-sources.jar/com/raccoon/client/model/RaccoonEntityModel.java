package com.raccoon.client.model;

import com.raccoon.entity.RaccoonEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;
import net.minecraft.class_5597;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

@Environment(EnvType.CLIENT)
public class RaccoonEntityModel<T extends RaccoonEntity> extends class_5597<T> {
    private final class_630 root;
    private final class_630 body;
    private final class_630 head;
    private final class_630 rightHindLeg;
    private final class_630 leftHindLeg;
    private final class_630 rightFrontLeg;
    private final class_630 leftFrontLeg;
    private final class_630 tail;

    public RaccoonEntityModel(class_630 root) {
        this.root = root;
        this.body = root.method_32086("body");
        this.head = root.method_32086("head");
        this.rightHindLeg = root.method_32086("right_hind_leg");
        this.leftHindLeg = root.method_32086("left_hind_leg");
        this.rightFrontLeg = root.method_32086("right_front_leg");
        this.leftFrontLeg = root.method_32086("left_front_leg");
        this.tail = this.body.method_32086("tail");
    }

    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();

        // Head at pivot (0.0F, 15.0F, -3.0F)
        class_5610 headData = modelPartData.method_32117("head",
                class_5606.method_32108()
                        .method_32101(0, 0).method_32097(-3.0F, -2.5F, -4.0F, 6.0F, 5.0F, 5.0F)
                        .method_32101(0, 11).method_32097(-2.0F, 0.5F, -6.0F, 4.0F, 2.0F, 2.0F),
                class_5603.method_32090(0.0F, 15.0F, -3.0F));

        // Ears on head
        headData.method_32117("right_ear",
                class_5606.method_32108().method_32101(15, 0).method_32097(-2.5F, -4.5F, -2.0F, 2.0F, 2.0F, 1.0F),
                class_5603.field_27701);
        headData.method_32117("left_ear",
                class_5606.method_32108().method_32101(21, 0).method_32097(0.5F, -4.5F, -2.0F, 2.0F, 2.0F, 1.0F),
                class_5603.field_27701);

        // Body at pivot (0.0F, 15.0F, 0.0F)
        class_5610 bodyData = modelPartData.method_32117("body",
                class_5606.method_32108()
                        .method_32101(24, 15).method_32097(-3.0F, -3.0F, -5.5F, 6.0F, 6.0F, 11.0F),
                class_5603.method_32090(0.0F, 15.0F, 0.0F));

        // Tail attached to body at rear
        bodyData.method_32117("tail",
                class_5606.method_32108()
                        .method_32101(30, 0).method_32097(-2.0F, -1.0F, 0.0F, 4.0F, 4.0F, 9.0F),
                class_5603.method_32090(0.0F, -1.0F, 5.0F));

        // Hind Legs
        modelPartData.method_32117("right_hind_leg",
                class_5606.method_32108().method_32101(0, 18).method_32097(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                class_5603.method_32090(-2.0F, 18.0F, 4.0F));
        modelPartData.method_32117("left_hind_leg",
                class_5606.method_32108().method_32101(8, 18).method_32097(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                class_5603.method_32090(2.0F, 18.0F, 4.0F));

        // Front Legs
        modelPartData.method_32117("right_front_leg",
                class_5606.method_32108().method_32101(0, 26).method_32097(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                class_5603.method_32090(-2.0F, 18.0F, -4.0F));
        modelPartData.method_32117("left_front_leg",
                class_5606.method_32108().method_32101(8, 26).method_32097(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                class_5603.method_32090(2.0F, 18.0F, -4.0F));

        return class_5607.method_32110(modelData, 64, 64);
    }

    @Override
    public class_630 method_32008() {
        return this.root;
    }

    @Override
    public void setAngles(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        this.resetPositions();

        this.head.field_3654 = headPitch * 0.017453292F;
        this.head.field_3675 = headYaw * 0.017453292F;

        if (entity.method_6172() || entity.method_24345()) {
            // SITTING POSE
            this.body.field_3656 = 17.5F;
            this.body.field_3655 = 1.0F;
            this.body.field_3654 = -0.7853982F; // -45 degrees

            this.head.field_3656 = 13.0F;
            this.head.field_3655 = -2.0F;
            this.head.field_3654 += 0.35F;

            this.rightHindLeg.field_3656 = 21.5F;
            this.rightHindLeg.field_3655 = 4.5F;
            this.rightHindLeg.field_3654 = -1.35F;
            this.rightHindLeg.field_3675 = -0.2F;

            this.leftHindLeg.field_3656 = 21.5F;
            this.leftHindLeg.field_3655 = 4.5F;
            this.leftHindLeg.field_3654 = -1.35F;
            this.leftHindLeg.field_3675 = 0.2F;

            this.rightFrontLeg.field_3656 = 18.0F;
            this.rightFrontLeg.field_3655 = -3.5F;
            this.rightFrontLeg.field_3654 = 0.55F;

            this.leftFrontLeg.field_3656 = 18.0F;
            this.leftFrontLeg.field_3655 = -3.5F;
            this.leftFrontLeg.field_3654 = 0.55F;

            this.tail.field_3654 = 0.65F;
            this.tail.field_3675 = class_3532.method_15362(animationProgress * 0.1F) * 0.15F;

        } else if (entity.isStanding()) {
            // STANDING UP ON TWO HIND LEGS POSE
            this.body.field_3656 = 12.0F;
            this.body.field_3655 = 0.0F;
            this.body.field_3654 = -1.5707964F; // -90 degrees upright

            this.head.field_3656 = 5.5F;
            this.head.field_3655 = 0.0F;
            this.head.field_3654 += 0.1F;

            this.rightHindLeg.field_3656 = 18.0F;
            this.rightHindLeg.field_3655 = 0.0F;
            this.rightHindLeg.field_3654 = 0.0F;

            this.leftHindLeg.field_3656 = 18.0F;
            this.leftHindLeg.field_3655 = 0.0F;
            this.leftHindLeg.field_3654 = 0.0F;

            this.rightFrontLeg.field_3656 = 9.0F;
            this.rightFrontLeg.field_3655 = -2.0F;
            this.rightFrontLeg.field_3654 = -1.1F + class_3532.method_15362(animationProgress * 0.2F) * 0.08F;
            this.rightFrontLeg.field_3674 = -0.2F;

            this.leftFrontLeg.field_3656 = 9.0F;
            this.leftFrontLeg.field_3655 = -2.0F;
            this.leftFrontLeg.field_3654 = -1.1F - class_3532.method_15362(animationProgress * 0.2F) * 0.08F;
            this.leftFrontLeg.field_3674 = 0.2F;

            this.tail.field_3654 = 1.35F;
            this.tail.field_3675 = class_3532.method_15362(animationProgress * 0.1F) * 0.1F;

        } else {
            // ON ALL 4'S (NORMAL QUADRUPED POSE)
            this.rightHindLeg.field_3654 = class_3532.method_15362(limbAngle * 0.6662F) * 1.4F * limbDistance;
            this.leftHindLeg.field_3654 = class_3532.method_15362(limbAngle * 0.6662F + 3.1415927F) * 1.4F * limbDistance;
            this.rightFrontLeg.field_3654 = class_3532.method_15362(limbAngle * 0.6662F + 3.1415927F) * 1.4F * limbDistance;
            this.leftFrontLeg.field_3654 = class_3532.method_15362(limbAngle * 0.6662F) * 1.4F * limbDistance;

            this.tail.field_3654 = -0.35F + class_3532.method_15362(limbAngle * 0.4F) * 0.1F * limbDistance;
            this.tail.field_3675 = class_3532.method_15362(animationProgress * 0.12F) * 0.15F;
        }
    }

    private void resetPositions() {
        this.body.field_3657 = 0.0F;
        this.body.field_3656 = 15.0F;
        this.body.field_3655 = 0.0F;
        this.body.field_3654 = 0.0F;
        this.body.field_3675 = 0.0F;
        this.body.field_3674 = 0.0F;

        this.head.field_3657 = 0.0F;
        this.head.field_3656 = 15.0F;
        this.head.field_3655 = -3.0F;
        this.head.field_3654 = 0.0F;
        this.head.field_3675 = 0.0F;
        this.head.field_3674 = 0.0F;

        this.rightHindLeg.field_3657 = -2.0F;
        this.rightHindLeg.field_3656 = 18.0F;
        this.rightHindLeg.field_3655 = 4.0F;
        this.rightHindLeg.field_3654 = 0.0F;
        this.rightHindLeg.field_3675 = 0.0F;
        this.rightHindLeg.field_3674 = 0.0F;

        this.leftHindLeg.field_3657 = 2.0F;
        this.leftHindLeg.field_3656 = 18.0F;
        this.leftHindLeg.field_3655 = 4.0F;
        this.leftHindLeg.field_3654 = 0.0F;
        this.leftHindLeg.field_3675 = 0.0F;
        this.leftHindLeg.field_3674 = 0.0F;

        this.rightFrontLeg.field_3657 = -2.0F;
        this.rightFrontLeg.field_3656 = 18.0F;
        this.rightFrontLeg.field_3655 = -4.0F;
        this.rightFrontLeg.field_3654 = 0.0F;
        this.rightFrontLeg.field_3675 = 0.0F;
        this.rightFrontLeg.field_3674 = 0.0F;

        this.leftFrontLeg.field_3657 = 2.0F;
        this.leftFrontLeg.field_3656 = 18.0F;
        this.leftFrontLeg.field_3655 = -4.0F;
        this.leftFrontLeg.field_3654 = 0.0F;
        this.leftFrontLeg.field_3675 = 0.0F;
        this.leftFrontLeg.field_3674 = 0.0F;

        this.tail.field_3654 = -0.2F;
        this.tail.field_3675 = 0.0F;
        this.tail.field_3674 = 0.0F;
    }
}
