package com.raccoon.client.model;

import com.raccoon.RaccoonMod;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_5601;

@Environment(EnvType.CLIENT)
public class RaccoonModelLayers {
    public static final class_5601 RACCOON = new class_5601(new class_2960(RaccoonMod.MOD_ID, "raccoon"), "main");
}
