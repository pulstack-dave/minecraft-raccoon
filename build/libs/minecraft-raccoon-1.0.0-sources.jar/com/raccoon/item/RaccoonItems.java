package com.raccoon.item;

import com.raccoon.RaccoonMod;
import com.raccoon.entity.RaccoonEntities;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class RaccoonItems {
    public static final class_1792 RACCOON_SPAWN_EGG = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960(RaccoonMod.MOD_ID, "raccoon_spawn_egg"),
            new class_1826(RaccoonEntities.RACCOON, 0x5C5856, 0x1E1E1E, new class_1792.class_1793())
    );

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(entries -> {
            entries.method_45421(RACCOON_SPAWN_EGG);
        });
    }
}
