package com.raccoon.entity;

import com.raccoon.entity.ai.RaccoonBegGoal;
import com.raccoon.entity.ai.RaccoonWashGoal;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1321;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1350;
import net.minecraft.class_1353;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1386;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1403;
import net.minecraft.class_1406;
import net.minecraft.class_1428;
import net.minecraft.class_1463;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class RaccoonEntity extends class_1321 {
    private static final class_2940<Boolean> STANDING = class_2945.method_12791(RaccoonEntity.class, class_2943.field_13323);
    private static final class_2940<Boolean> WASHING = class_2945.method_12791(RaccoonEntity.class, class_2943.field_13323);

    public RaccoonEntity(class_1299<? extends class_1321> entityType, class_1937 world) {
        super(entityType, world);
        this.method_6173(false);
    }

    public static class_5132.class_5133 createRaccoonAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 12.0)
                .method_26868(class_5134.field_23719, 0.3)
                .method_26868(class_5134.field_23721, 4.0);
    }

    @Override
    protected void method_5693() {
        super.method_5693();
        this.field_6011.method_12784(STANDING, false);
        this.field_6011.method_12784(WASHING, false);
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10556("Standing", this.isStanding());
        nbt.method_10556("Washing", this.isWashing());
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        this.setStanding(nbt.method_10577("Standing"));
        this.setWashing(nbt.method_10577("Washing"));
    }

    public boolean isStanding() {
        return this.field_6011.method_12789(STANDING);
    }

    public void setStanding(boolean standing) {
        this.field_6011.method_12778(STANDING, standing);
    }

    public boolean isWashing() {
        return this.field_6011.method_12789(WASHING);
    }

    public void setWashing(boolean washing) {
        this.field_6011.method_12778(WASHING, washing);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(1, new class_1347(this));
        this.field_6201.method_6277(2, new class_1386(this));
        this.field_6201.method_6277(3, new RaccoonBegGoal(this, 8.0F));
        this.field_6201.method_6277(4, new RaccoonWashGoal(this));
        this.field_6201.method_6277(5, new class_1366(this, 1.2, true));
        this.field_6201.method_6277(6, new class_1350(this, 1.15, 10.0F, 2.0F, false));
        this.field_6201.method_6277(7, new class_1341(this, 1.0));
        this.field_6201.method_6277(8, new class_1391(this, 1.1, class_1856.method_8091(
                class_1802.field_16998, class_1802.field_28659, class_1802.field_8229, class_1802.field_8429, class_1802.field_8209, class_1802.field_8279
        ), false));
        this.field_6201.method_6277(9, new class_1353(this, 1.1));
        this.field_6201.method_6277(10, new class_1394(this, 1.0));
        this.field_6201.method_6277(11, new class_1361(this, class_1657.class, 8.0F));
        this.field_6201.method_6277(12, new class_1376(this));

        this.field_6185.method_6277(1, new class_1403(this));
        this.field_6185.method_6277(2, new class_1406(this));
        this.field_6185.method_6277(3, new class_1399(this).method_6318());
        this.field_6185.method_6277(4, new class_1400<>(this, class_1428.class, false, (target) -> !this.method_6181()));
        this.field_6185.method_6277(5, new class_1400<>(this, class_1463.class, false, (target) -> !this.method_6181()));
    }

    public boolean isFavoriteFood(class_1799 stack) {
        class_1792 item = stack.method_7909();
        return item == class_1802.field_16998
                || item == class_1802.field_28659
                || item == class_1802.field_8229
                || item == class_1802.field_8279
                || item == class_1802.field_8429
                || item == class_1802.field_8209
                || item == class_1802.field_8373
                || item == class_1802.field_8509
                || item == class_1802.field_8803
                || item == class_1802.field_8423
                || item == class_1802.field_8726
                || item == class_1802.field_8544
                || item == class_1802.field_8504
                || item == class_1802.field_8752
                || item == class_1802.field_8071;
    }

    @Override
    public net.minecraft.class_1924 method_48926() {
        return super.method_37908();
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return this.isFavoriteFood(stack);
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);

        if (this.method_37908().field_9236) {
            boolean consume = this.method_6171(player) || this.method_6181() || (this.isFavoriteFood(itemStack) && !this.method_6181());
            return consume ? class_1269.field_21466 : class_1269.field_5811;
        }

        if (this.method_6181()) {
            if (this.method_6171(player)) {
                if (this.isFavoriteFood(itemStack) && this.method_6032() < this.method_6063()) {
                    if (!player.method_31549().field_7477) {
                        itemStack.method_7934(1);
                    }
                    this.method_6025(4.0F);
                    this.method_5783(class_3417.field_20614, 1.0F, 1.0F);
                    this.method_37908().method_8421(this, (byte) 7); // Heart particles
                    return class_1269.field_5812;
                }

                if (this.method_6481(itemStack) && this.method_5618() == 0 && this.method_6482()) {
                    if (!player.method_31549().field_7477) {
                        itemStack.method_7934(1);
                    }
                    this.method_6480(player);
                    this.method_5783(class_3417.field_20614, 1.0F, 1.0F);
                    this.method_37908().method_8421(this, (byte) 7);
                    return class_1269.field_5812;
                }

                // Toggle sitting / standing / following
                class_1269 result = super.method_5992(player, hand);
                if (!result.method_23665() || this.method_6109()) {
                    this.method_24346(!this.method_24345());
                    this.method_6179(!this.method_6172());
                    this.field_6282 = false;
                    this.field_6189.method_6340();
                    this.method_5980(null);
                    return class_1269.field_5812;
                }
                return result;
            }
        } else if (this.isFavoriteFood(itemStack)) {
            if (!player.method_31549().field_7477) {
                itemStack.method_7934(1);
            }

            this.method_5783(class_3417.field_20614, 1.0F, 1.0F);

            if (this.field_5974.method_43048(3) == 0) {
                this.method_6170(player);
                this.field_6189.method_6340();
                this.method_5980(null);
                this.method_24346(true);
                this.method_6179(true);
                this.method_37908().method_8421(this, (byte) 7); // Hearts
            } else {
                this.method_37908().method_8421(this, (byte) 6); // Smoke
            }
            return class_1269.field_5812;
        }

        return super.method_5992(player, hand);
    }

    @Override
    public void method_6173(boolean tamed) {
        super.method_6173(tamed);
        if (tamed) {
            this.method_5996(class_5134.field_23716).method_6192(24.0);
            this.method_6033(24.0F);
        } else {
            this.method_5996(class_5134.field_23716).method_6192(12.0);
        }
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) {
        RaccoonEntity baby = RaccoonEntities.RACCOON.method_5883(world);
        if (baby != null && this.method_6181()) {
            baby.method_6174(this.method_6139());
            baby.method_6173(true);
        }
        return baby;
    }

    @Nullable
    @Override
    protected class_3414 method_5994() {
        return class_3417.field_18056;
    }

    @Nullable
    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_18061;
    }

    @Nullable
    @Override
    protected class_3414 method_6002() {
        return class_3417.field_18059;
    }
}
