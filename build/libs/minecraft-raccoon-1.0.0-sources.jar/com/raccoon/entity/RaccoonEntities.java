package com.raccoon.entity;

import com.raccoon.RaccoonMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_7923;

public class RaccoonEntities {
    public static final class_1299<RaccoonEntity> RACCOON = class_2378.method_10230(
            class_7923.field_41177,
            new class_2960(RaccoonMod.MOD_ID, "raccoon"),
            FabricEntityTypeBuilder.create(class_1311.field_6294, RaccoonEntity::new)
                    .dimensions(class_4048.method_18385(0.6F, 0.7F))
                    .build()
    );

    public static void register() {
        // Ensures static initializer runs
    }
}
