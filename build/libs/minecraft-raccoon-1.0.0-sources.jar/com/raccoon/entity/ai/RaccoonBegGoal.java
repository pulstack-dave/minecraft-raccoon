package com.raccoon.entity.ai;

import com.raccoon.entity.RaccoonEntity;
import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_4051;

public class RaccoonBegGoal extends class_1352 {
    private final RaccoonEntity raccoon;
    private final class_1937 world;
    private final float distance;
    private class_1657 beggingPlayer;
    private int timer;
    private final class_4051 validPlayerPredicate;

    public RaccoonBegGoal(RaccoonEntity raccoon, float distance) {
        this.raccoon = raccoon;
        this.world = raccoon.method_37908();
        this.distance = distance;
        this.validPlayerPredicate = class_4051.method_36626().method_18418(distance);
        this.method_6265(EnumSet.of(class_4134.field_18406, class_4134.field_18405));
    }

    @Override
    public boolean method_6264() {
        if (this.raccoon.method_6172()) {
            return false;
        }
        this.beggingPlayer = this.world.method_18462(this.validPlayerPredicate, this.raccoon);
        return this.beggingPlayer != null && this.isHoldingFood(this.beggingPlayer);
    }

    @Override
    public boolean method_6266() {
        if (this.beggingPlayer == null || !this.beggingPlayer.method_5805()) {
            return false;
        }
        if (this.raccoon.method_5858(this.beggingPlayer) > (double)(this.distance * this.distance)) {
            return false;
        }
        return this.timer > 0 && this.isHoldingFood(this.beggingPlayer);
    }

    @Override
    public void method_6269() {
        this.raccoon.setStanding(true);
        this.timer = 40 + this.raccoon.method_6051().method_43048(40);
    }

    @Override
    public void method_6270() {
        this.raccoon.setStanding(false);
        this.beggingPlayer = null;
    }

    @Override
    public void method_6268() {
        this.raccoon.method_5988().method_6230(this.beggingPlayer.method_23317(), this.beggingPlayer.method_23320(), this.beggingPlayer.method_23321(), 10.0F, (float)this.raccoon.method_5978());
        --this.timer;
    }

    private boolean isHoldingFood(class_1657 player) {
        for (class_1799 stack : player.method_5877()) {
            if (this.raccoon.isFavoriteFood(stack)) {
                return true;
            }
        }
        return false;
    }
}
