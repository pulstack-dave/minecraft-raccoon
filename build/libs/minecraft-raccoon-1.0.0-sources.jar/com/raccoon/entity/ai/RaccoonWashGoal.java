package com.raccoon.entity.ai;

import com.raccoon.entity.RaccoonEntity;
import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class RaccoonWashGoal extends class_1352 {
    private final RaccoonEntity raccoon;
    private final class_1937 world;
    private int washTimer;
    private class_2338 targetWaterPos;

    public RaccoonWashGoal(RaccoonEntity raccoon) {
        this.raccoon = raccoon;
        this.world = raccoon.method_37908();
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        if (this.raccoon.method_6172() || this.raccoon.method_6109()) {
            return false;
        }
        if (this.raccoon.method_6051().method_43048(120) != 0) {
            return false;
        }
        class_2338 raccoonPos = this.raccoon.method_24515();
        for (class_2338 pos : class_2338.method_10097(raccoonPos.method_10069(-3, -1, -3), raccoonPos.method_10069(3, 1, 3))) {
            if (this.world.method_8320(pos).method_27852(class_2246.field_10382) || this.world.method_8320(pos).method_27852(class_2246.field_10593)) {
                this.targetWaterPos = pos.method_10062();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean method_6266() {
        return this.washTimer > 0 && this.targetWaterPos != null;
    }

    @Override
    public void method_6269() {
        this.washTimer = 60 + this.raccoon.method_6051().method_43048(40);
        this.raccoon.setWashing(true);
        if (this.targetWaterPos != null) {
            this.raccoon.method_5942().method_6337(this.targetWaterPos.method_10263() + 0.5, this.targetWaterPos.method_10264() + 1.0, this.targetWaterPos.method_10260() + 0.5, 1.1);
        }
    }

    @Override
    public void method_6270() {
        this.raccoon.setWashing(false);
        this.targetWaterPos = null;
    }

    @Override
    public void method_6268() {
        if (this.targetWaterPos != null) {
            this.raccoon.method_5988().method_20248(this.targetWaterPos.method_10263() + 0.5, this.targetWaterPos.method_10264() + 0.5, this.targetWaterPos.method_10260() + 0.5);
            if (this.raccoon.method_5649(this.targetWaterPos.method_10263() + 0.5, this.targetWaterPos.method_10264() + 0.5, this.targetWaterPos.method_10260() + 0.5) < 4.0) {
                // Splash particles
                if (this.world.field_9236) {
                    this.world.method_8406(class_2398.field_11202,
                            this.targetWaterPos.method_10263() + 0.5 + (this.world.field_9229.method_43058() - 0.5) * 0.4,
                            this.targetWaterPos.method_10264() + 0.8,
                            this.targetWaterPos.method_10260() + 0.5 + (this.world.field_9229.method_43058() - 0.5) * 0.4,
                            0.0, 0.1, 0.0);
                }
                if (this.washTimer % 15 == 0) {
                    this.world.method_8396(null, this.raccoon.method_24515(), class_3417.field_14818, class_3419.field_15254, 0.4F, 1.2F);
                }
            }
        }
        --this.washTimer;
    }
}
